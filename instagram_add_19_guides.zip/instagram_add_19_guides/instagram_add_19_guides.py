#!/usr/bin/env python3

import sys
from gi.repository import Gimp, GObject, Gio, GLib

class AddInstagram19Guides(Gimp.PlugIn):
    def do_query_procedures(self):
        return ["plug-in-add-instagram-guides"]

    def do_create_procedure(self, name):
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None
        )
        procedure.set_image_types("*")
        procedure.set_menu_label("Add Instagram Guides (19 guides)")
        procedure.add_menu_path("<Image>/Guides/")
        procedure.set_documentation(
            "Adds vertical guides for Instagram carousel layout",
            "Adds 19 evenly spaced vertical guides for Instagram layout.",
            name
        )
        procedure.set_attribution("Gizmo", "Gizmo", "2025")
        return procedure

    def run(self, procedure, run_mode, image, n_drawables, drawables, config):
        try:
            width = image.get_width()
            spacing = width // 20
            for i in range(1, 20):
                image.add_vguide(i * spacing)

            # ✅ Show GIMP status message
            Gimp.message("✅ Added 19 vertical Instagram-style guides.")
            return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())
        except Exception as e:
            Gimp.message(f"❌ Error: {e}")
            return procedure.new_return_values(Gimp.PDBStatusType.FAIL, GLib.Error())

Gimp.main(AddInstagram19Guides.__gtype__, sys.argv)
