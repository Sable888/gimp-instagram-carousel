"""Widgets to interactively edit actions (procedures/constraints)."""
