"""Main plug-in dialogs."""

from .main import *
