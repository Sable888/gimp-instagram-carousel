"""Functions dealing with strings, file/directory paths and file extensions."""
