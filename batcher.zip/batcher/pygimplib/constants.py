"""Constants used in other modules."""

MENU_PATH_SEPARATOR = '/'
TEXT_FILE_ENCODING = 'utf-8'
