#!/usr/bin/env python3

import sys
import gi

gi.require_version('Gimp', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gimp, GObject, Gio, GLib, Gtk
import os

class ScaleAndCenterLayers(Gimp.PlugIn):
    __gtype_name__ = 'ScaleAndCenterLayers'

    def do_query_procedures(self):
        return ['plug-in-scale-center-layers']

    def do_create_procedure(self, name):
        procedure = Gimp.ImageProcedure.new(
            self,
            'plug-in-scale-center-layers',
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None
        )
        procedure.set_menu_label("Scale and Center Layers")
        procedure.set_attribution("You", "You", "2025")
        procedure.set_documentation(
            "Scale all visible layers to match the canvas height.",
            "Each visible layer is scaled proportionally to match canvas height (1350px), and centered horizontally.",
            'plug-in-scale-center-layers'
        )
        procedure.set_image_types("*")
        procedure.add_menu_path("<Image>/Guides/")
        return procedure

    def run(self, procedure, run_mode, image, n_drawables, drawables, config):
        canvas_width = image.get_width()
        canvas_height = image.get_height()

        layers = image.get_layers()

        for layer in layers:
            if not layer.get_visible():
                continue

            original_width = layer.get_width()
            original_height = layer.get_height()

            scale_ratio = canvas_height / original_height
            new_width = int(original_width * scale_ratio)
            new_height = canvas_height

            # Move the layer to (0, 0) before resizing
            layer.set_offsets(0, 0)
            layer.scale(new_width, new_height, False)

            # Center the layer horizontally after scaling
            offset_x = int((canvas_width - new_width) / 2)
            layer.set_offsets(offset_x, 0)

            Gimp.message(f"✅ Scaled and centered layer: {layer.get_name()}")

        return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())

Gimp.main(ScaleAndCenterLayers.__gtype__, sys.argv)
