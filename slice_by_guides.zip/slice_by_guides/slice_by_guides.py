#!/usr/bin/env python3

import sys
from gi.repository import Gimp, GObject, Gio, GLib

class SliceByGuidesPlugin(Gimp.PlugIn):
    def do_query_procedures(self):
        return ['slice-by-guides']

    def do_create_procedure(self, name):
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None
        )
        procedure.set_image_types("*")
        procedure.set_menu_label("Slice by Guides")
        procedure.add_menu_path("<Image>/Guides/")
        procedure.set_documentation(
            "Slices image using guides with GIMP’s built-in guillotine.",
            "Slices image using guides with GIMP’s built-in guillotine.",
            name
        )
        procedure.set_attribution("You", "You", "2025")
        return procedure

    def run(self, procedure, run_mode, image, n_drawables, drawables, config):
        # Call the built-in guillotine plugin
        guillotine_proc = Gimp.get_pdb().lookup_procedure("plug-in-guillotine")
        guillotine_config = guillotine_proc.create_config()

        guillotine_config.set_property("run-mode", Gimp.RunMode.NONINTERACTIVE)
        guillotine_config.set_property("image", image)

        guillotine_proc.run(guillotine_config)
        Gimp.message("✅ Image sliced using guides.")
        return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())

Gimp.main(SliceByGuidesPlugin.__gtype__, sys.argv)
